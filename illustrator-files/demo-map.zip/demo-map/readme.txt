Base map from axismaps

https://contours.axismaps.com/#10/19.3155/-99.1735


Additional data from OSM using the QuickOSM plugin for QGIS